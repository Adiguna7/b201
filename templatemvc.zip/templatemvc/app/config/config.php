<?php
define('BASEURL', 'http://localhost/sewaja/public');

define('DB_HOST', 'b201-db');
define('DB_USER', 'root');
define('DB_PASS', '12345678');
define('DB_NAME', 'b201');
define('DB_PORT', '3306');

?>